

// const Works =()=>{
//     return(
//         <>
//         <div className="elementor-widget-wrap elementor-element-populated">
// 						<div className="elementor-element elementor-element-25a3ad97 elementor-widget__width-initial elementor-absolute elementor-widget elementor-widget-sixam-animator" data-id="25a3ad97" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="sixam-animator.default">
// 				<div className="elementor-widget-container">
			
//         <div className="animator-wrapper">

         
            
//                                     <div className="image xAxisMove ">
//                         <img loading="lazy" decoding="async" width="74" height="82" src="https://stackfood.app/wp-content/uploads/2023/08/Group-1597884143.png" className="item-1" alt="Group 1597884143"/>                                            </div>
                
             
                
            
//         </div>
// 		</div>
// 				</div>
// 				<div className="elementor-element elementor-element-6b175072 elementor-widget__width-initial elementor-absolute elementor-widget elementor-widget-sixam-animator" data-id="6b175072" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="sixam-animator.default">
// 				<div className="elementor-widget-container">
			
//         <div className="animator-wrapper">

           
//                                     <div className="image xAxisMove ">
//                         <img loading="lazy" decoding="async" width="74" height="82" src="https://stackfood.app/wp-content/uploads/2023/08/Group-1597884143.png" className="item-1" alt="Group 1597884143"/>                                            </div>
                
              
                
            
//         </div>
// 		</div>
// 				</div>
// 				<div className="elementor-element elementor-element-d742d57 sf_heading_two sf elementor-widget elementor-widget-heading" data-id="d742d57" data-element_type="widget" data-widget_type="heading.default">
// 				<div className="elementor-widget-container">
// 			<h2 className="elementor-heading-title elementor-size-default">How Does StackFood  <span className="color-animation animate"> Work? </span>

// </h2>		</div>
// 				</div>
// 				<div className="elementor-element elementor-element-797f799 sf_p_one elementor-widget elementor-widget-heading" data-id="797f799" data-element_type="widget" data-widget_type="heading.default">
// 				<div className="elementor-widget-container">
// 			<p className="elementor-heading-title elementor-size-default">StackFood is designed to make your business more flexible and cost effective across all users. So you can ensure successful order delivery each time. 
// </p>		</div>
// 				</div>
// 				<div className="elementor-element elementor-element-4ff087f3 order_model_tab elementor-widget elementor-widget-sixam-tab" data-id="4ff087f3" data-element_type="widget" data-widget_type="sixam-tab.default">
// 				<div className="elementor-widget-container">
			
// <div className="tab-wrapper">
   
//         <div className="dynamic_tab_wrapper">
//         <div className="tabs-items">
//             <ul>
//                                 <p id="target_className" className=" order_confirmation_model.restaurant">
//                 </p>
//                 <p id="add_className" className=" animate active">
//                 </p>
//                 <li>
//                     <h3>
// 						<a href="#order_confirmation_model.restaurant" className="tab_link_item active">Order Accepted by Restaurant</a>
// 					</h3>
//                 </li>
//                                 <p id="target_className" className=" order_confirmation_model.deliveryman">
//                 </p>
//                 <p id="add_className" className=" animate active">
//                 </p>
//                 <li>
//                     <h3>
// 						<a href="#order_confirmation_model.deliveryman" className="tab_link_item">Order Accepted by Deliveryman</a>
// 					</h3>
//                 </li>
//                             </ul>
//         </div>
//     </div>

    

//     </div>
// 		</div>
// 				</div>
// 				<section className="elementor-section elementor-inner-section elementor-element elementor-element-1d7b6120 order_confirmation_model color-animation restaurant animated-fast elementor-section-boxed elementor-section-height-default elementor-section-height-default ma_icon_active animate animated zoomIn" data-id="1d7b6120" data-element_type="section" data-settings="{&quot;animation&quot;:&quot;zoomIn&quot;}">
// 						<div className="elementor-container elementor-column-gap-default">
// 					<div className="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-4d214854" data-id="4d214854" data-element_type="column">
// 			<div className="elementor-widget-wrap elementor-element-populated">
// 						<div className="elementor-element elementor-element-3bae8949 elementor-widget__width-initial elementor-absolute sf_order_elips_one animated-fast elementor-view-default elementor-widget elementor-widget-icon animated zoomIn" data-id="3bae8949" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;zoomIn&quot;}" data-widget_type="icon.default">
// 				<div className="elementor-widget-container">
// 					<div className="elementor-icon-wrapper">
// 			<div className="elementor-icon">
// 			<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none"><circle cx="7" cy="7" r="6" fill="#FF5722" stroke="white" stroke-width="2"></circle></svg>			</div>
// 		</div>
// 				</div>
// 				</div>
// 				<div className="elementor-element elementor-element-5cf03ac7 elementor-widget__width-initial elementor-absolute e-transform elementor-view-default elementor-widget elementor-widget-icon" data-id="5cf03ac7" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_transform_rotateZ_effect&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:270,&quot;sizes&quot;:[]},&quot;_transform_rotateZ_effect_laptop&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_rotateZ_effect_tablet&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_rotateZ_effect_mobile&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}" data-widget_type="icon.default">
// 				<div className="elementor-widget-container">
// 					<div className="elementor-icon-wrapper">
// 			<div className="elementor-icon">
// 			<svg xmlns="http://www.w3.org/2000/svg" width="8" height="12" viewBox="0 0 8 12" fill="none"><path d="M7.41 1.41L2.83 6L7.41 10.59L6 12L0 6L6 0L7.41 1.41Z" fill="#FF5722"></path></svg>			</div>
// 		</div>
// 				</div>
// 				</div>
// 				<div className="elementor-element elementor-element-3cc2911f elementor-widget__width-initial elementor-absolute e-transform elementor-hidden-desktop elementor-hidden-laptop elementor-hidden-tablet elementor-view-default elementor-widget elementor-widget-icon" data-id="3cc2911f" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_transform_rotateZ_effect&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:270,&quot;sizes&quot;:[]},&quot;_transform_rotateZ_effect_laptop&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_rotateZ_effect_tablet&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_rotateZ_effect_mobile&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}" data-widget_type="icon.default">
// 				<div className="elementor-widget-container">
// 					<div className="elementor-icon-wrapper">
// 			<div className="elementor-icon">
// 			<svg xmlns="http://www.w3.org/2000/svg" width="8" height="12" viewBox="0 0 8 12" fill="none"><path d="M7.41 1.41L2.83 6L7.41 10.59L6 12L0 6L6 0L7.41 1.41Z" fill="#FF5722"></path></svg>			</div>
// 		</div>
// 				</div>
// 				</div>
// 				<div className="elementor-element elementor-element-88319cd elementor-widget__width-initial elementor-absolute e-transform elementor-view-default elementor-widget elementor-widget-icon" data-id="88319cd" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_transform_rotateZ_effect&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:0,&quot;sizes&quot;:[]},&quot;_transform_rotateZ_effect_laptop&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_rotateZ_effect_tablet&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_rotateZ_effect_mobile&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}" data-widget_type="icon.default">
// 				<div className="elementor-widget-container">
// 					<div className="elementor-icon-wrapper">
// 			<div className="elementor-icon">
// 			<svg xmlns="http://www.w3.org/2000/svg" width="8" height="12" viewBox="0 0 8 12" fill="none"><path d="M7.41 1.41L2.83 6L7.41 10.59L6 12L0 6L6 0L7.41 1.41Z" fill="#FF5722"></path></svg>			</div>
// 		</div>
// 				</div>
// 				</div>
// 				<div className="elementor-element elementor-element-7a55ad06 elementor-widget__width-initial elementor-absolute e-transform elementor-hidden-mobile elementor-view-default elementor-widget elementor-widget-icon" data-id="7a55ad06" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_transform_rotateZ_effect&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:90,&quot;sizes&quot;:[]},&quot;_transform_rotateZ_effect_laptop&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_rotateZ_effect_tablet&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_rotateZ_effect_mobile&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}" data-widget_type="icon.default">
// 				<div className="elementor-widget-container">
// 					<div className="elementor-icon-wrapper">
// 			<div className="elementor-icon">
// 			<svg xmlns="http://www.w3.org/2000/svg" width="8" height="12" viewBox="0 0 8 12" fill="none"><path d="M7.41 1.41L2.83 6L7.41 10.59L6 12L0 6L6 0L7.41 1.41Z" fill="#FF5722"></path></svg>			</div>
// 		</div>
// 				</div>
// 				</div>
// 				<div className="elementor-element elementor-element-7cb9e45 elementor-widget__width-initial elementor-absolute elementor-widget elementor-widget-heading" data-id="7cb9e45" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="heading.default">
// 				<div className="elementor-widget-container">
// 			<h4 className="elementor-heading-title elementor-size-default">1. Customer places order through app or web</h4>		</div>
// 				</div>
// 				<div className="elementor-element elementor-element-7aa151dc elementor-widget__width-initial elementor-absolute elementor-widget elementor-widget-heading" data-id="7aa151dc" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="heading.default">
// 				<div className="elementor-widget-container">
// 			<h4 className="elementor-heading-title elementor-size-default">5. Customer receives order from deliveryman
// </h4>		</div>
// 				</div>
// 				<div className="elementor-element elementor-element-3861a172 elementor-widget__width-initial elementor-absolute elementor-widget elementor-widget-heading" data-id="3861a172" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="heading.default">
// 				<div className="elementor-widget-container">
// 			<h4 className="elementor-heading-title elementor-size-default">2. Restaurant accepts the order and starts to prepare food
// </h4>		</div>
// 				</div>
// 				<div className="elementor-element elementor-element-27d4397a elementor-widget__width-initial elementor-absolute elementor-widget elementor-widget-heading" data-id="27d4397a" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="heading.default">
// 				<div className="elementor-widget-container">
// 			<h4 className="elementor-heading-title elementor-size-default">3. Restaurant prepares food and handover to deliveryman
// </h4>		</div>
// 				</div>
// 				<div className="elementor-element elementor-element-4d6ee6a5 elementor-widget__width-initial elementor-absolute elementor-widget elementor-widget-heading" data-id="4d6ee6a5" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="heading.default">
// 				<div className="elementor-widget-container">
// 			<h4 className="elementor-heading-title elementor-size-default">4. Deliveryman receives food from the restaurant and out for delivery
// </h4>		</div>
// 				</div>
// 				<div className="elementor-element elementor-element-7d89f660 elementor-widget__width-initial elementor-absolute sf_to_down elementor-widget-laptop__width-initial elementor-hidden-mobile elementor-view-default elementor-widget elementor-widget-icon" data-id="7d89f660" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="icon.default">
// 				<div className="elementor-widget-container">
// 					<div className="elementor-icon-wrapper">
// 			<div className="elementor-icon">
// 			<svg xmlns="http://www.w3.org/2000/svg" width="504" height="66" viewBox="0 0 504 66" fill="none"><path d="M1 56V11C1 5.47715 5.47715 1 11 1H493C498.523 1 503 5.47715 503 11V65.5" stroke="#E55D28" stroke-dasharray="6 6"></path></svg>			</div>
// 		</div>
// 				</div>
// 				</div>
// 				<div className="elementor-element elementor-element-37a6e26b elementor-widget__width-initial elementor-absolute sf_to_down elementor-widget-laptop__width-initial elementor-hidden-desktop elementor-hidden-laptop elementor-hidden-tablet elementor-view-default elementor-widget elementor-widget-icon" data-id="37a6e26b" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="icon.default">
// 				<div className="elementor-widget-container">
// 					<div className="elementor-icon-wrapper">
// 			<div className="elementor-icon">
// 			<svg xmlns="http://www.w3.org/2000/svg" width="66" height="113" viewBox="0 0 66 113" fill="none"><path d="M66 1H11C5.47715 1 1 5.47715 1 11V113" stroke="#E55D28" stroke-dasharray="6 6"></path></svg>			</div>
// 		</div>
// 				</div>
// 				</div>
// 				<div className="elementor-element elementor-element-2074d4f elementor-widget__width-initial elementor-absolute sf_to_down elementor-hidden-mobile elementor-view-default elementor-widget elementor-widget-icon" data-id="2074d4f" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="icon.default">
// 				<div className="elementor-widget-container">
// 					<div className="elementor-icon-wrapper">
// 			<div className="elementor-icon">
// 			<svg xmlns="http://www.w3.org/2000/svg" width="403" height="179" viewBox="0 0 403 179" fill="none"><path d="M193 1H392C397.523 1 402 5.47715 402 11V168C402 173.523 397.523 178 392 178H0" stroke="#E55D28" stroke-dasharray="6 6"></path></svg>			</div>
// 		</div>
// 				</div>
// 				</div>
// 				<div className="elementor-element elementor-element-45e821ff elementor-widget__width-initial elementor-absolute sf_to_down elementor-hidden-desktop elementor-hidden-laptop elementor-hidden-tablet elementor-view-default elementor-widget elementor-widget-icon" data-id="45e821ff" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="icon.default">
// 				<div className="elementor-widget-container">
// 					<div className="elementor-icon-wrapper">
// 			<div className="elementor-icon">
// 			<svg xmlns="http://www.w3.org/2000/svg" width="38" height="298" viewBox="0 0 38 298" fill="none"><path d="M0 297H27C32.5228 297 37 292.523 37 287V11C37 5.47716 32.5228 1 27 1H9.67045" stroke="#E55D28" stroke-dasharray="6 6"></path></svg>			</div>
// 		</div>
// 				</div>
// 				</div>
// 				<div className="elementor-element elementor-element-3e6f9d38 elementor-widget__width-initial elementor-absolute sf_to_up elementor-hidden-mobile elementor-view-default elementor-widget elementor-widget-icon" data-id="3e6f9d38" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="icon.default">
// 				<div className="elementor-widget-container">
// 					<div className="elementor-icon-wrapper">
// 			<div className="elementor-icon">
// 			<svg xmlns="http://www.w3.org/2000/svg" width="221" height="108" viewBox="0 0 221 108" fill="none"><path d="M1 0V97C1 102.523 5.47715 107 11 107H220.5" stroke="#E55D28" stroke-dasharray="6 6"></path></svg>			</div>
// 		</div>
// 				</div>
// 				</div>
// 				<div className="elementor-element elementor-element-4fc18ea9 elementor-widget__width-initial elementor-absolute sf_to_down elementor-hidden-desktop elementor-hidden-laptop elementor-hidden-tablet elementor-view-default elementor-widget elementor-widget-icon" data-id="4fc18ea9" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="icon.default">
// 				<div className="elementor-widget-container">
// 					<div className="elementor-icon-wrapper">
// 			<div className="elementor-icon">
// 			<svg xmlns="http://www.w3.org/2000/svg" width="67" height="31" viewBox="0 0 67 31" fill="none"><path d="M0 1H56C61.5228 1 66 5.47715 66 11V30.5" stroke="#E55D28" stroke-dasharray="6 6"></path></svg>			</div>
// 		</div>
// 				</div>
// 				</div>
// 				<div className="elementor-element elementor-element-15143cb5 sf_order_elips_one elementor-widget-tablet__width-initial elementor-hidden-mobile elementor-widget elementor-widget-image" data-id="15143cb5" data-element_type="widget" data-widget_type="image.default">
// 				<div className="elementor-widget-container">
// 													<img loading="eager" decoding="async" width="1024" height="471"
//                                                      src="https://stackfood.app/wp-content/uploads/2024/01/how-does-stackfood-work-1024x471.webp" 
//                                                      className="attachment-large size-large wp-image-19320" alt="how does stackfood work"
//                                                      />													</div>
// 				</div>
// 				<div className="elementor-element elementor-element-44cdc597 sf_order_elips_one elementor-widget-tablet__width-initial elementor-hidden-desktop elementor-hidden-laptop elementor-hidden-tablet elementor-widget elementor-widget-image" data-id="44cdc597" data-element_type="widget" data-widget_type="image.default">
// 				<div className="elementor-widget-container">
// 													<img loading="eager" decoding="async" width="558" 
//                                                     height="814" src="https://stackfood.app/wp-content/uploads/2024/01/how-does-stackfood-work-2.webp" className="attachment-large size-large wp-image-19322" alt="How Does StackFood Work?"
//                                                     />													</div>
// 				</div>
// 					</div>
// 		</div>
// 					</div>
// 		</section>
// 				<section className="elementor-section elementor-inner-section elementor-element elementor-element-3b4d5054 order_confirmation_model color-animation deliveryman animated-fast elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-invisible animate" data-id="3b4d5054" data-element_type="section" data-settings="{&quot;animation&quot;:&quot;zoomIn&quot;}">
// 						<div className="elementor-container elementor-column-gap-default">
// 					<div className="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-3aefc783" data-id="3aefc783" data-element_type="column">
// 			<div className="elementor-widget-wrap elementor-element-populated">
// 						<div className="elementor-element elementor-element-517deede elementor-widget-tablet__width-initial elementor-hidden-mobile elementor-widget elementor-widget-image" data-id="517deede" data-element_type="widget" data-widget_type="image.default">
// 				<div className="elementor-widget-container">
// 													<img loading="eager" decoding="async" width="1516"
//                                                      height="822"
//                                                       src="https://stackfood.app/wp-content/uploads/2024/10/stackfood-order-accepted-by-deliveryman.webp" 
//                                                       className="attachment-full size-full wp-image-21714" alt="StackFood Order Accepted By Deliveryman"
//                                                      />													</div>
// 				</div>
// 				<div className="elementor-element elementor-element-6ef251f1 elementor-widget-tablet__width-initial elementor-hidden-desktop elementor-hidden-laptop elementor-hidden-tablet elementor-widget elementor-widget-image" data-id="6ef251f1" data-element_type="widget" data-widget_type="image.default">
// 				<div className="elementor-widget-container">
// 													<img loading="eager" decoding="async" width="640" height="1002"
//                                                      src="https://stackfood.app/wp-content/uploads/2023/08/Frame-1597884077.png"
//                                                       className="attachment-large size-large wp-image-17317" alt="Frame 1597884077"
//                                                       />													</div>
// 				</div>
// 				<div className="elementor-element elementor-element-577dce1 elementor-widget__width-initial elementor-absolute sf_to_down elementor-widget-tablet__width-initial elementor-hidden-mobile elementor-view-default elementor-widget elementor-widget-icon" data-id="577dce1" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="icon.default">
// 				<div className="elementor-widget-container">
// 					<div className="elementor-icon-wrapper">
// 			<div className="elementor-icon">
// 			<svg xmlns="http://www.w3.org/2000/svg" width="504" height="92" viewBox="0 0 504 92" fill="none"><path d="M1 92V11C1 5.47715 5.47715 1 11 1H493C498.523 1 503 5.47715 503 11V35" stroke="#E55D28" stroke-dasharray="6 6"></path></svg>			</div>
// 		</div>
// 				</div>
// 				</div>
// 				<div className="elementor-element elementor-element-6a3b04b7 elementor-widget__width-initial elementor-absolute sf_to_down elementor-widget-tablet__width-initial elementor-hidden-desktop elementor-hidden-laptop elementor-hidden-tablet elementor-view-default elementor-widget elementor-widget-icon" data-id="6a3b04b7" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="icon.default">
// 				<div className="elementor-widget-container">
// 					<div className="elementor-icon-wrapper">
// 			<div className="elementor-icon">
// 			<svg xmlns="http://www.w3.org/2000/svg" width="118" height="158" viewBox="0 0 118 158" fill="none"><path d="M30.9348 1H11C5.47715 1 1 5.47715 1 11V147C1 152.523 5.47715 157 11 157H118" stroke="#E55D28" stroke-dasharray="6 6"></path></svg>			</div>
// 		</div>
// 				</div>
// 				</div>
// 				<div className="elementor-element elementor-element-1db1f33e elementor-widget__width-initial elementor-absolute sf_to_up elementor-hidden-mobile elementor-view-default elementor-widget elementor-widget-icon" data-id="1db1f33e" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="icon.default">
// 				<div className="elementor-widget-container">
// 					<div className="elementor-icon-wrapper">
// 			<div className="elementor-icon">
// 			<svg xmlns="http://www.w3.org/2000/svg" width="367" height="68" viewBox="0 0 367 68" fill="none"><path d="M0 67.5H158C163.523 67.5 168 63.0228 168 57.5V11C168 5.47715 172.477 1 178 1L367 1" stroke="#E55D28" stroke-dasharray="6 6"></path></svg>			</div>
// 		</div>
// 				</div>
// 				</div>
// 				<div className="elementor-element elementor-element-6782d5bf elementor-widget__width-initial elementor-absolute sf_to_down elementor-hidden-desktop elementor-hidden-laptop elementor-hidden-tablet elementor-view-default elementor-widget elementor-widget-icon" data-id="6782d5bf" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="icon.default">
// 				<div className="elementor-widget-container">
// 					<div className="elementor-icon-wrapper">
// 			<div className="elementor-icon">
// 			<svg xmlns="http://www.w3.org/2000/svg" width="54" height="196" viewBox="0 0 54 196" fill="none"><path d="M15.1429 195H43C48.5228 195 53 190.523 53 185V11C53 5.47715 48.5228 1 43 1H0" stroke="#E55D28" stroke-dasharray="6 6"></path></svg>			</div>
// 		</div>
// 				</div>
// 				</div>
// 				<div className="elementor-element elementor-element-141faff3 elementor-widget__width-initial elementor-absolute sf_to_down elementor-hidden-mobile elementor-view-default elementor-widget elementor-widget-icon" data-id="141faff3" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="icon.default">
// 				<div className="elementor-widget-container">
// 					<div className="elementor-icon-wrapper">
// 			<div className="elementor-icon">
// 			<svg xmlns="http://www.w3.org/2000/svg" width="101" height="261" viewBox="0 0 101 261" fill="none"><path d="M0 0.5H90.5C96.0228 0.5 100.5 4.97715 100.5 10.5V250.5C100.5 256.023 96.0228 260.5 90.5 260.5H25" stroke="#E55D28" stroke-dasharray="6 6"></path></svg>			</div>
// 		</div>
// 				</div>
// 				</div>
// 				<div className="elementor-element elementor-element-7b02dfc8 elementor-widget__width-initial elementor-absolute sf_to_down elementor-hidden-desktop elementor-hidden-laptop elementor-hidden-tablet elementor-view-default elementor-widget elementor-widget-icon" data-id="7b02dfc8" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="icon.default">
// 				<div className="elementor-widget-container">
// 					<div className="elementor-icon-wrapper">
// 			<div className="elementor-icon">
// 			<svg xmlns="http://www.w3.org/2000/svg" width="80" height="107" viewBox="0 0 80 107" fill="none"><path d="M0 106H69C74.5228 106 79 101.523 79 96V0" stroke="#E55D28" stroke-dasharray="6 6"></path></svg>			</div>
// 		</div>
// 				</div>
// 				</div>
// 				<div className="elementor-element elementor-element-745b9e21 elementor-widget__width-initial elementor-absolute sf_to_up elementor-hidden-mobile elementor-view-default elementor-widget elementor-widget-icon" data-id="745b9e21" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="icon.default">
// 				<div className="elementor-widget-container">
// 					<div className="elementor-icon-wrapper">
// 			<div className="elementor-icon">
// 			<svg xmlns="http://www.w3.org/2000/svg" width="1" height="100" viewBox="0 0 1 100" fill="none"><path d="M0.5 0V99.5" stroke="#E55D28" stroke-dasharray="6 6"></path></svg>			</div>
// 		</div>
// 				</div>
// 				</div>
// 				<div className="elementor-element elementor-element-7fca5ebd elementor-widget__width-initial elementor-absolute sf_to_up elementor-hidden-desktop elementor-hidden-laptop elementor-hidden-tablet elementor-view-default elementor-widget elementor-widget-icon" data-id="7fca5ebd" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="icon.default">
// 				<div className="elementor-widget-container">
// 					<div className="elementor-icon-wrapper">
// 			<div className="elementor-icon">
// 			<svg xmlns="http://www.w3.org/2000/svg" width="62" height="52" viewBox="0 0 62 52" fill="none"><path d="M1 52V17.0116V11C1 5.47715 5.47715 1 11 1H62" stroke="#E55D28" stroke-dasharray="6 6"></path></svg>			</div>
// 		</div>
// 				</div>
// 				</div>
// 				<div className="elementor-element elementor-element-2f24b8bd elementor-widget__width-initial elementor-absolute e-transform elementor-view-default elementor-widget elementor-widget-icon" data-id="2f24b8bd" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_transform_rotateZ_effect&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:270,&quot;sizes&quot;:[]},&quot;_transform_rotateZ_effect_laptop&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_rotateZ_effect_tablet&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_rotateZ_effect_mobile&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}" data-widget_type="icon.default">
// 				<div className="elementor-widget-container">
// 					<div className="elementor-icon-wrapper">
// 			<div className="elementor-icon">
// 			<svg xmlns="http://www.w3.org/2000/svg" width="8" height="12" viewBox="0 0 8 12" fill="none"><path d="M7.41 1.41L2.83 6L7.41 10.59L6 12L0 6L6 0L7.41 1.41Z" fill="#FF5722"></path></svg>			</div>
// 		</div>
// 				</div>
// 				</div>
// 				<div className="elementor-element elementor-element-446cb8a0 elementor-widget__width-initial elementor-absolute e-transform e-transform elementor-hidden-desktop elementor-hidden-laptop elementor-hidden-tablet elementor-view-default elementor-widget elementor-widget-icon" data-id="446cb8a0" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_transform_rotateZ_effect&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:0,&quot;sizes&quot;:[]},&quot;_transform_flipX_effect&quot;:&quot;transform&quot;,&quot;_transform_rotateZ_effect_laptop&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_rotateZ_effect_tablet&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_rotateZ_effect_mobile&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}" data-widget_type="icon.default">
// 				<div className="elementor-widget-container">
// 					<div className="elementor-icon-wrapper">
// 			<div className="elementor-icon">
// 			<svg xmlns="http://www.w3.org/2000/svg" width="8" height="12" viewBox="0 0 8 12" fill="none"><path d="M7.41 1.41L2.83 6L7.41 10.59L6 12L0 6L6 0L7.41 1.41Z" fill="#FF5722"></path></svg>			</div>
// 		</div>
// 				</div>
// 				</div>
// 				<div className="elementor-element elementor-element-17bd9e46 elementor-widget__width-initial elementor-absolute e-transform elementor-hidden-mobile elementor-view-default elementor-widget elementor-widget-icon" data-id="17bd9e46" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_transform_rotateZ_effect&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:0,&quot;sizes&quot;:[]},&quot;_transform_rotateZ_effect_laptop&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_rotateZ_effect_tablet&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_rotateZ_effect_mobile&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}" data-widget_type="icon.default">
// 				<div className="elementor-widget-container">
// 					<div className="elementor-icon-wrapper">
// 			<div className="elementor-icon">
// 			<svg xmlns="http://www.w3.org/2000/svg" width="8" height="12" viewBox="0 0 8 12" fill="none"><path d="M7.41 1.41L2.83 6L7.41 10.59L6 12L0 6L6 0L7.41 1.41Z" fill="#FF5722"></path></svg>			</div>
// 		</div>
// 				</div>
// 				</div>
// 				<div className="elementor-element elementor-element-7e961230 elementor-widget__width-initial elementor-absolute e-transform elementor-view-default elementor-widget elementor-widget-icon" data-id="7e961230" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_transform_rotateZ_effect&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:0,&quot;sizes&quot;:[]},&quot;_transform_rotateZ_effect_laptop&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_rotateZ_effect_tablet&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_rotateZ_effect_mobile&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}" data-widget_type="icon.default">
// 				<div className="elementor-widget-container">
// 					<div className="elementor-icon-wrapper">
// 			<div className="elementor-icon">
// 			<svg xmlns="http://www.w3.org/2000/svg" width="8" height="12" viewBox="0 0 8 12" fill="none"><path d="M7.41 1.41L2.83 6L7.41 10.59L6 12L0 6L6 0L7.41 1.41Z" fill="#FF5722"></path></svg>			</div>
// 		</div>
// 				</div>
// 				</div>
// 				<div className="elementor-element elementor-element-22b05b3c elementor-widget__width-initial elementor-absolute e-transform elementor-view-default elementor-widget elementor-widget-icon" data-id="22b05b3c" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_transform_rotateZ_effect&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:90,&quot;sizes&quot;:[]},&quot;_transform_rotateZ_effect_laptop&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_rotateZ_effect_tablet&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_rotateZ_effect_mobile&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}" data-widget_type="icon.default">
// 				<div className="elementor-widget-container">
// 					<div className="elementor-icon-wrapper">
// 			<div className="elementor-icon">
// 			<svg xmlns="http://www.w3.org/2000/svg" width="8" height="12" viewBox="0 0 8 12" fill="none"><path d="M7.41 1.41L2.83 6L7.41 10.59L6 12L0 6L6 0L7.41 1.41Z" fill="#FF5722"></path></svg>			</div>
// 		</div>
// 				</div>
// 				</div>
// 				<div className="elementor-element elementor-element-185ae52f elementor-widget__width-initial elementor-absolute sf_order_elips_one elementor-view-default elementor-invisible elementor-widget elementor-widget-icon" data-id="185ae52f" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;zoomIn&quot;}" data-widget_type="icon.default">
// 				<div className="elementor-widget-container">
// 					<div className="elementor-icon-wrapper">
// 			<div className="elementor-icon">
// 			<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none"><circle cx="7" cy="7" r="6" fill="#FF5722" stroke="white" stroke-width="2"></circle></svg>			</div>
// 		</div>
// 				</div>
// 				</div>
// 				<div className="elementor-element elementor-element-2b47e265 elementor-widget__width-initial elementor-absolute elementor-widget elementor-widget-heading" data-id="2b47e265" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="heading.default">
// 				<div className="elementor-widget-container">
// 			<h4 className="elementor-heading-title elementor-size-default">1. Customer places order through
// app or web</h4>		</div>
// 				</div>
// 				<div className="elementor-element elementor-element-36b9d5ff elementor-widget__width-initial elementor-absolute elementor-widget elementor-widget-heading" data-id="36b9d5ff" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="heading.default">
// 				<div className="elementor-widget-container">
// 			<h4 className="elementor-heading-title elementor-size-default">2. Deliveryman accepts the order
// and sends to the restaurant</h4>		</div>
// 				</div>
// 				<div className="elementor-element elementor-element-47be2aa3 elementor-widget__width-initial elementor-absolute elementor-widget elementor-widget-heading" data-id="47be2aa3" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="heading.default">
// 				<div className="elementor-widget-container">
// 			<h4 className="elementor-heading-title elementor-size-default">3. Restaurant receives order from
// deliveryman and prepares food</h4>		</div>
// 				</div>
// 				<div className="elementor-element elementor-element-12ccde9d elementor-widget__width-initial elementor-absolute elementor-widget elementor-widget-heading" data-id="12ccde9d" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="heading.default">
// 				<div className="elementor-widget-container">
// 			<h4 className="elementor-heading-title elementor-size-default">4. Restaurant handovers the food to deliveryman after preparing food
// </h4>		</div>
// 				</div>
// 				<div className="elementor-element elementor-element-407c6896 elementor-widget__width-initial elementor-absolute elementor-widget elementor-widget-heading" data-id="407c6896" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="heading.default">
// 				<div className="elementor-widget-container">
// 			<h4 className="elementor-heading-title elementor-size-default">5. Deliveryman receives food from
// restaurant and out for delivery</h4>		</div>
// 				</div>
// 					</div>
// 		</div>
// 					</div>
// 		</section>
// 					</div>
//         </>
//     )
// }
// export default Works